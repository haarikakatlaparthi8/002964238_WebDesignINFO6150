const Joi = require("joi");

const express = require("express"),
      app = express(),
      mongoose = require("mongoose"),
      bcrypt = require("bcrypt"),
      bodyParser = require("body-parser");

const saltRounds = 10;

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

mongoose.connect("mongodb+srv://katlaparthih:webd@cluster0.8dium0t.mongodb.net/webd", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
  
}) .then(() => console.log('Connected to MongoDB'))
.catch(err => console.log('Could not connect to MongoDB', err));


// Home Page
app.get("/", (req, res) => {
  res.send("Welcome to Assignment 8 - INFO6150.");
});

// Create new user
// User model schema
const userSchema = new mongoose.Schema({
  fullName: { type: String, required: true, minlength: 3, maxlength: 100 },
  email: { type: String, required: true, unique: true, minlength: 5, maxlength: 255 },
  password: { type: String, required: true, minlength: 8, maxlength: 1024 }
});

// User model
const User = mongoose.model('User', userSchema);

// Create a new user
app.post('/user/create', async (req, res) => {
  // Validate the request body
  const { error } = validateUser(req.body);
  if (error) return res.status(400).send(error.details[0].message);

  // Check if the user already exists
  let user = await User.findOne({ email: req.body.email });
  if (user) return res.status(400).send('User already registered.');

  // Create a new user object
  user = new User({
    fullName: req.body.fullName,
    email: req.body.email,
    password: await bcrypt.hash(req.body.password, await bcrypt.genSalt(10))
  });

  // Save the user to the database
  await user.save();

  res.send(user);
});

function validateUser(user) {
  const schema = Joi.object({
    fullName: Joi.string().min(3).max(100).required(),
    email: Joi.string().min(5).max(255).required().email(),
    password: Joi.string().min(8).max(50).required().regex(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/)
  });

  return schema.validate(user);
}
function validateUser(user) {
  const schema = Joi.object({
    fullName: Joi.string().min(3).max(100).required(),
    email: Joi.string().min(5).max(255).required().email(),
    password: Joi.string().min(8).max(50).required().regex(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/)
  });

  return schema.validate(user);
}
// Update user details
app.put('/user/edit/:email', async (req, res) => {
  const email = req.params.email;
  const { fullName, password } = req.body;

  try {
    // Check if user exists
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Validate full name and password
    if (!fullName) {
      return res.status(400).json({ message: 'Full name is required' });
    }
    if (!password || password.length < 8) {
      return res.status(400).json({ message: 'Password must be at least 8 characters long' });
    }

    // Update user's full name and password
    await User.updateOne({ email }, { fullName, password: await bcrypt.hash(password, 10) });
    res.status(200).json({ message: 'User updated successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Internal server error' });
  }
});
// Get all users
app.get("/user/getAll", async (req, res) => {

  User.find({}, function (err, users) {
      users.forEach(user => delete user.password);
      const newResult = users.map(item => {
        return {
          id: item._id,
          email: item.email,
          password: item.password
        }
      })
      res.send(newResult);
  });
  
});

// Delete user
app.delete('/user/delete/:email', async (req, res) => {
  const email = req.params.email;

  try {
    // Check if user exists
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Delete user from database
    await User.deleteOne({ email });
    res.status(200).json({ message: 'User deleted successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// Server config block
app.listen(8000, () => {
  console.log("Server started at port 8000");
});