PART A

In this Assignment, we have created two pages website for Student Counseling HTML controls.

We have included a logo and used below controls and tags

Favicon
Table
Form
Images
Hyperlink
Button
Image
Line break
Footer
Header



